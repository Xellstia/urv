// app/javascript/controllers/sidebar_controller.js
import { Controller } from "@hotwired/stimulus"

// data-controller="sidebar"
// targets: aside, label
export default class extends Controller {
  static targets = ["aside", "label"]

  connect() {
    // Для наглядности — видно в консоли, что контроллер подключился
    // console.debug("[sidebar] connected")
  }

  toggle() {
    // Меняем ширину панели
    this.asideTarget.classList.toggle("w-64")
    this.asideTarget.classList.toggle("w-16")

    // Прячем/показываем подписи пунктов
    this.labelTargets.forEach(el => {
      el.classList.toggle("hidden")
    })
  }
}
